<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row justify-content-center">
        <div class="col-lg-12">

            
            <div class="d-flex justify-content-between mb-4">
                <a href="<?php echo e(route('admin.articles.index')); ?>" class="btn px-4 py-2"
                   style="background-color: #F0F5FF; color: #5B93FF; border-radius: 8px;">
                    <i class="fas fa-arrow-left me-2"></i> Back
                </a>
            </div>

            <!-- Article Details -->
            <div class="card border-0 rounded-4 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h1 class="fw-bold mb-3"><?php echo e($article->title); ?></h1>
                    <div class="mb-2 text-muted">
                        <i class="far fa-calendar-alt me-1"></i> <?php echo e($article->created_at->format('d M Y')); ?>

                    </div>
                    <p class="lead" style="color: #5F738C;"><?php echo e($article->description); ?></p>
                    <?php if($article->thumbnail): ?>
                        <div class="text-center my-4">
                            <img src="<?php echo e(asset('storage/' . $article->thumbnail)); ?>" class="img-fluid rounded" style="max-width: 100%;">
                        </div>
                    <?php endif; ?>

                    <?php if($article->subheadings->count()): ?>
                        <?php $__currentLoopData = $article->subheadings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subheading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-4">
                                <h3 class="fw-bold"><?php echo e($subheading->title); ?></h3>
                                <?php $__currentLoopData = $subheading->paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p style="color: #5F738C;"><?php echo e($paragraph->content); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Comments Section for Admin -->
            <div class="card border-0 rounded-4 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h3 class="fw-bold fs-5 mb-4">Komentar (<?php echo e($article->comments->count()); ?>)</h3>

                    <!-- Comments List -->
                    <div class="comments-list">
                        <?php $__empty_1 = true; $__currentLoopData = $article->comments()->with('user')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="comment-item border-bottom py-3">
                                <div class="d-flex align-items-start">
                                    <div class="d-flex justify-content-center align-items-center rounded-circle me-3"
                                         style="width: 40px; height: 40px; background-color: #F0F5FF;">
                                        <i class="fas fa-user" style="color: #5B93FF;"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <h6 class="mb-0 fw-medium"><?php echo e($comment->user->name); ?></h6>
                                            <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                        </div>
                                        <p class="mb-2" style="color: #5F738C;"><?php echo e($comment->content); ?></p>

                                        <!-- Admin delete comment -->
                                        <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>"
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-link text-danger"
                                                    onclick="return confirm('Apakah Anda yakin ingin menghapus komentar ini?')">
                                                <i class="fas fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-4">
                                <p class="text-muted mb-0">Belum ada komentar.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Magang\kersa\kersa\resources\views/articles/show.blade.php ENDPATH**/ ?>