 

<?php $__env->startSection('title', 'Buat Tim Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card shadow-sm profile-edit-card"> 
                <div class="card-header bg-white text-center py-3">
                    <h4 class="mb-0 profile-section-title">Buat Tim Baru</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('team.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> 

                        
                        <div class="mb-4 text-center"> 
                            <label for="logo" class="form-label d-block mb-3 profile-photo-upload-area">
                                <div class="profile-photo-wrapper mb-2">
                                    
                                    <img src="<?php echo e(asset('assets/img/team-placeholder.png')); ?>" 
                                         alt="Team Logo" class="img-fluid editable-profile-photo" width="120" height="120">
                                    <div class="profile-photo-overlay">
                                        <i class="fas fa-camera"></i> 
                                    </div>
                                </div>
                                <div class="btn btn-sm btn-outline-secondary d-block mx-auto upload-button">Pilih Logo</div>
                            </label>
                            <input type="file" class="form-control d-none" id="logo" name="logo" accept="image/*" required>
                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Maksimal ukuran 2MB (jpeg, png, jpg, gif).</small>
                        </div>

                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Tim</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="manager_name" class="form-label">Nama Manajer</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['manager_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="manager_name" name="manager_name" value="<?php echo e(old('manager_name')); ?>" required>
                            <?php $__errorArgs = ['manager_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="contact" class="form-label">Kontak Tim</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact" name="contact" value="<?php echo e(old('contact')); ?>" required>
                            <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="location" class="form-label">Lokasi Tim</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="location" name="location" value="<?php echo e(old('location')); ?>" required>
                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="gender_category" class="form-label">Kategori Gender Tim</label>
                            <select class="form-select <?php $__errorArgs = ['gender_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gender_category" name="gender_category" required>
                                <option value="">Pilih Kategori</option>
                                <option value="male" <?php echo e(old('gender_category') == 'male' ? 'selected' : ''); ?>>Pria</option>
                                <option value="female" <?php echo e(old('gender_category') == 'female' ? 'selected' : ''); ?>>Wanita</option>
                                <option value="mixed" <?php echo e(old('gender_category') == 'mixed' ? 'selected' : ''); ?>>Campuran</option>
                            </select>
                            <?php $__errorArgs = ['gender_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="member_count" class="form-label">Jumlah Anggota</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['member_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="member_count" name="member_count" value="<?php echo e(old('member_count', 1)); ?>" min="1" max="10" required>
                            <?php $__errorArgs = ['member_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Masukkan jumlah anggota tim (misal: 5).</small>
                        </div>

                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi Tim (Opsional)</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description" rows="3"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-grid gap-2 mt-4"> 
                            <button type="submit" class="btn btn-primary btn-lg">Buat Tim</button>
                            <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>"> 
    <style>
        /* Gaya tambahan khusus untuk halaman buat tim, meniru edit.profile */
        .profile-edit-card {
            border-radius: 12px;
            box-shadow:
                8px 8px 0px 0px var(--shadow-color-cf2585), /* Shadow magenta tebal */
                5px 5px 15px rgba(0, 0, 0, 0.1) !important; /* Shadow lembut di belakang, dengan !important */
            position: relative;
            z-index: 1;
            border: 1px solid #dee2e6; /* Border tipis untuk konsistensi */
        }

        .profile-section-title {
            /* Gaya untuk judul di header card, jika ada kustomisasi */
            color: #212529; /* Warna teks gelap default */
            font-weight: 600; /* Misalnya lebih tebal */
        }

        /* Gaya untuk area upload foto/logo, sama dengan edit.blade.php */
        .profile-photo-upload-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            width: fit-content;
            margin: 0 auto;
            position: relative;
        }

        .profile-photo-wrapper {
            position: relative;
            width: 120px;
            height: 120px;
            border-radius: 10px;
            overflow: hidden;
            border: 2px solid #eee;
        }

        .editable-profile-photo {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: opacity 0.3s ease;
        }

        .profile-photo-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            border-radius: 10px;
        }

        .profile-photo-overlay .fas {
            color: #fff;
            font-size: 2rem;
        }

        .profile-photo-upload-area:hover .profile-photo-overlay {
            opacity: 1;
        }

        .upload-button {
            width: 120px;
            margin-top: 10px;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }

        /* Definisi variabel warna jika belum ada di tempat lain, atau pastikan ini sesuai dengan branding Anda */
        :root {
            --shadow-color-cf2585: #cf2585; /* Ini harus sesuai dengan warna primer Anda atau warna yang digunakan di shadow */
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
    

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const logoInput = document.getElementById('logo');
            const logoPreview = document.querySelector('.editable-profile-photo');
            const logoUploadArea = document.querySelector('.profile-photo-upload-area');

            // Event listener untuk memicu klik input file saat area di klik
            logoUploadArea.addEventListener('click', function(event) {
                if (event.target !== logoInput) {
                    event.preventDefault();
                    logoInput.click();
                }
            });

            // Fungsi untuk menampilkan preview gambar
            function previewImage(inputElement, previewElement) {
                if (inputElement.files && inputElement.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewElement.src = e.target.result;
                    };
                    reader.readAsDataURL(inputElement.files[0]);
                }
            }

            // Panggil fungsi previewImage saat input file berubah
            logoInput.addEventListener('change', function(event) {
                previewImage(event.target, logoPreview);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('../layouts/master_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Magang\kersa\kersa\resources\views/front/teams/create.blade.php ENDPATH**/ ?>