<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card shadow-sm profile-edit-card">
                <div class="card-header bg-white text-center py-3">
                    
                    <h4 class="mb-0 profile-section-title">Edit Informasi Profile</h4>
                </div>
                <div class="card-body">
                    
                    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> 

                        
                        <div class="mb-4 text-center">
                            <label for="profile_photo" class="form-label d-block mb-3 profile-photo-upload-area">
                                
                                <div class="profile-photo-wrapper mb-2">
                                    <img src="<?php echo e(Auth::user()->profile->profile_photo ? asset('storage/' . Auth::user()->profile->profile_photo) : asset('assets/img/profile-placeholder.png')); ?>"
                                         alt="Profile Photo" class="img-fluid editable-profile-photo" width="120" height="120">
                                    
                                    <div class="profile-photo-overlay">
                                        <i class="fas fa-camera"></i> </div>
                                </div>
                                <div class="btn btn-sm btn-outline-secondary d-block mx-auto upload-button">Ganti Foto</div>
                            </label>
                            <input type="file" class="form-control d-none" id="profile_photo" name="profile_photo" accept="image/*">
                            <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name', Auth::user()->profile->name ?? Auth::user()->name)); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="birthdate" class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="birthdate" name="birthdate" value="<?php echo e(old('birthdate', Auth::user()->profile->birthdate)); ?>">
                            <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="gender" class="form-label">Jenis Kelamin</label>
                            <select class="form-select <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gender" name="gender">
                                <option value="">Pilih Jenis Kelamin</option>
                                
                                <option value="male" <?php echo e(old('gender', Auth::user()->profile->gender) == 'male' ? 'selected' : ''); ?>>Laki-laki</option>
                                <option value="female" <?php echo e(old('gender', Auth::user()->profile->gender) == 'female' ? 'selected' : ''); ?>>Perempuan</option>
                                
                                
                                <option value="other" <?php echo e(old('gender', Auth::user()->profile->gender) == 'other' ? 'selected' : ''); ?>>Lainnya</option>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" disabled>
                            <div class="form-text">Email tidak dapat diubah di sini.</div>
                        </div>

                        
                        <div class="mb-3">
                            <label for="phone_number" class="form-label">Nomor Telepon</label>
                            <input type="tel" class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone_number" name="phone_number" value="<?php echo e(old('phone_number', Auth::user()->profile->phone_number)); ?>">
                            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-4">
                            <label for="social_media" class="form-label">Akun Sosial Media (Link)</label>
                            <input type="url" class="form-control <?php $__errorArgs = ['social_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="social_media" name="social_media" value="<?php echo e(old('social_media', Auth::user()->profile->social_media)); ?>" placeholder="https://instagram.com/namapengguna">
                            <?php $__errorArgs = ['social_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Simpan Perubahan</button>
                            <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
    <style>
        /* Gaya tambahan khusus untuk halaman edit profil */
        .profile-edit-card {
            border-radius: 12px;
            /* Aplikasikan box-shadow yang diinginkan di sini */
            box-shadow:
                8px 8px 0px 0px var(--shadow-color-cf2585), /* Shadow magenta tebal */
                5px 5px 15px rgba(0, 0, 0, 0.1) !important; /* Shadow lembut di belakang, dengan !important */
            position: relative;
            z-index: 1;
            border: 1px solid #dee2e6; /* Border tipis untuk konsistensi */
        }

        .profile-photo-upload-area {
            display: flex;
            flex-direction: column; /* Mengatur item secara vertikal */
            align-items: center; /* Pusatkan item secara horizontal */
            cursor: pointer;
            width: fit-content; /* Sesuaikan lebar dengan kontennya */
            margin: 0 auto; /* Pusatkan area upload */
            position: relative; /* Untuk positioning overlay */
        }

        .profile-photo-wrapper {
            position: relative;
            width: 120px; /* Ukuran wrapper sama dengan gambar */
            height: 120px;
            border-radius: 10px; /* Border radius sama dengan gambar */
            overflow: hidden; /* Pastikan tidak ada yang keluar */
            border: 2px solid #eee; /* Border yang sama dengan gambar */
        }

        .editable-profile-photo {
            width: 100%;
            height: 100%;
            object-fit: cover; /* Penting untuk cropping gambar */
            transition: opacity 0.3s ease;
        }

        .profile-photo-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4); /* Warna overlay saat hover */
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0; /* Sembunyikan secara default */
            transition: opacity 0.3s ease;
            border-radius: 10px; /* Cocokkan dengan radius wrapper */
        }

        .profile-photo-overlay .fas {
            color: #fff;
            font-size: 2rem;
        }

        .profile-photo-upload-area:hover .profile-photo-overlay {
            opacity: 1; /* Tampilkan overlay saat hover pada area */
        }

        .upload-button {
            width: 120px; /* Sesuaikan lebar tombol dengan lebar foto */
            margin-top: 10px; /* Beri sedikit jarak dari foto */
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
    

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const profilePhotoInput = document.getElementById('profile_photo');
            const profilePhotoPreview = document.querySelector('.editable-profile-photo');
            const profilePhotoUploadArea = document.querySelector('.profile-photo-upload-area'); // Area klik utama

            // HANYA SATU EVENT LISTENER DI SINI UNTUK MENCEGAH DOUBLE POP-UP
            profilePhotoUploadArea.addEventListener('click', function(event) {
                // Mencegah event dari elemen anak menyebar ke atas (jika ada tombol atau area lain yang bisa diklik di dalamnya)
                // Ini penting karena <label> secara default akan memicu input yang terkait dengannya.
                // Kondisi `event.target !== profilePhotoInput` memastikan bahwa jika pengguna
                // benar-benar mengklik langsung input file yang tersembunyi (misalnya melalui keyboard navigation),
                // maka perilaku default input file tidak dicegah.
                if (event.target !== profilePhotoInput) {
                    event.preventDefault();
                    profilePhotoInput.click(); // Memicu klik input file
                }
            });

            // Fungsi untuk menampilkan preview gambar
            function previewImage(inputElement, previewElement) {
                if (inputElement.files && inputElement.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewElement.src = e.target.result;
                    };
                    reader.readAsDataURL(inputElement.files[0]);
                }
            }

            // Panggil fungsi previewImage saat input file berubah
            profilePhotoInput.addEventListener('change', function(event) {
                previewImage(event.target, profilePhotoPreview);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('../layouts/master_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Magang\kersa\kersa\resources\views/front/profile/edit.blade.php ENDPATH**/ ?>