<?php $__env->startSection('content'); ?>
<style>
/* Custom select dropdown styling, updated for consistency */
.custom-select-dropdown {
    background-color: #f5f5f5; /* Light gray for a modern, clean look */
    border-radius: 0.5rem; /* More rounded corners for sporty youthful feel */
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    font-weight: 500;
    color: #495057;
    transition: all 0.3s ease;
    border: 1px solid #dee2e6; /* subtle border */
}
.custom-select-dropdown:focus {
    border-color: #00617a; /* Primary color for focus */
    box-shadow: 0 0 0 0.2rem rgba(0, 97, 122, 0.25); /* Primary color shadow */
}

.custom-select-dropdown option {
    font-weight: normal;
}

.logo-img {
    width: 120px;
    height: 60px;
    object-fit: contain;
    border-radius: 0.375rem; /* Consistent rounded corners */
}
</style>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between mb-4">
        
        <a href="<?php echo e(route('admin.sponsors.index')); ?>" class="btn px-4 py-2"
            style="background-color: #F0F5FF; color: #5B93FF; border-radius: 8px;">
            <i class="fas fa-arrow-left me-2"></i> Kembali
        </a>
    </div>

    <div class="card shadow-sm border-0 mb-4 rounded-4">
        <div class="card-body p-4">
            <form action="<?php echo e(route('admin.sponsors.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-md-6">
                        
                        <label class="form-label text-secondary fw-medium">Logo <span class="text-danger">*</span> <small class="text-muted">(Max 2MB, JPG, PNG, WebP)</small></label>
                        <div class="position-relative border rounded-3 d-flex align-items-center justify-content-center <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="height: 240px;">
                            <input type="file" id="logo" name="logo" accept="image/*" required
                                class="position-absolute w-100 h-100 opacity-0 cursor-pointer" style="z-index: 3;">
                            <div id="logo-preview-overlay" class="position-absolute w-100 h-100 d-flex align-items-center justify-content-center border border-success bg-white rounded-3" style="pointer-events: none;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none" viewBox="0 0 24 24" stroke="#36b37e" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m-7-7h14"/>
                                </svg>
                            </div>
                            
                            <img id="logo-image-preview" src="#" alt="Logo Preview" class="position-absolute w-100 h-100 d-none" style="object-fit: contain; border-radius: 0.25rem;">
                        </div>
                        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6">
                        <div class="d-flex flex-column justify-content-between h-100">
                            <div class="mb-3">
                                <label class="form-label text-secondary fw-medium">Sponsor Name</label>
                                
                                <input type="text" class="form-control border-success rounded-3 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label text-secondary fw-medium">Sponsor Size</label>
                                
                                <select name="sponsor_size" class="form-select border-success rounded-3 <?php $__errorArgs = ['sponsor_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="" disabled <?php echo e(old('sponsor_size') ? '' : 'selected'); ?>>-- Select Size --</option>
                                    <option value="xxl" <?php echo e(old('sponsor_size') == 'xxl' ? 'selected' : ''); ?>>XXL</option>
                                    <option value="xl" <?php echo e(old('sponsor_size') == 'xl' ? 'selected' : ''); ?>>XL</option>
                                    <option value="l" <?php echo e(old('sponsor_size') == 'l' ? 'selected' : ''); ?>>L</option>
                                    <option value="m" <?php echo e(old('sponsor_size') == 'm' ? 'selected' : ''); ?>>M</option>
                                    <option value="s" <?php echo e(old('sponsor_size') == 's' ? 'selected' : ''); ?>>S</option>
                                </select>
                                <?php $__errorArgs = ['sponsor_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label text-secondary fw-medium">Description</label>
                    
                    <textarea class="form-control border-success rounded-3 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" rows="3"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex justify-content-start">
                    <button type="submit" class="btn btn-success px-4 py-2">Save Sponsor</button>
                    
                    <a href="<?php echo e(route('admin.sponsors.index')); ?>" class="btn btn-outline-secondary ms-2 px-4 py-2">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .form-control:focus, .form-select:focus {
        border-color: #24E491;
        box-shadow: 0 0 0 0.25rem rgba(36, 228, 145, 0.25);
    }

    .btn-primary {
        background-color: #5932EA;
        border-color: #5932EA;
    }

    .btn-primary:hover {
        background-color: #4920D5;
        border-color: #4920D5;
    }

    .btn-success {
        background-color: #24E491;
        border-color: #24E491;
    }

    .btn-success:hover {
        background-color: #1fb47a;
        border-color: #1fb47a;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoInput = document.getElementById('logo');
        const logoImagePreview = document.getElementById('logo-image-preview');
        const logoPreviewOverlay = document.getElementById('logo-preview-overlay');

        logoInput.addEventListener('change', function (e) {
            if (e.target.files && e.target.files[0]) {
                const file = e.target.files[0];
                const fileSize = file.size / (1024 * 1024); // Size in MB
                const maxFileSize = 2; // Max size in MB (corresponds to 2048 KB in backend validation)

                // Client-side validation for file size
                if (fileSize > maxFileSize) {
                    alert(`Ukuran logo tidak boleh lebih dari ${maxFileSize} MB.`);
                    logoInput.value = ''; // Clear the selected file
                    logoImagePreview.src = '#';
                    logoImagePreview.classList.add('d-none');
                    logoPreviewOverlay.classList.remove('d-none');
                    return; // Stop further processing
                }

                const reader = new FileReader();
                reader.onload = function (event) {
                    logoImagePreview.src = event.target.result;
                    logoImagePreview.classList.remove('d-none');
                    logoPreviewOverlay.classList.add('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                logoImagePreview.src = '#';
                logoImagePreview.classList.add('d-none');
                logoPreviewOverlay.classList.remove('d-none');
            }
        });

        // If there's an old value for logo (e.g., after validation error with a file)
        // this part would typically be for an 'edit' form, but included for completeness
        // in case old() can store temp file paths, though usually it only stores string path
        // if ('<?php echo e(old('logo')); ?>') { // This check is mostly for edit forms with existing images
        //     logoImagePreview.src = '<?php echo e(asset('storage/' . old('logo'))); ?>';
        //     logoImagePreview.classList.remove('d-none');
        //     logoPreviewOverlay.classList.add('d-none');
        // }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Magang\kersa\kersa\resources\views/sponsors/create.blade.php ENDPATH**/ ?>