<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-white rounded-4 shadow-sm p-4" style="border: 1px solid rgba(0, 97, 122, 0.1);"> 
                <div class="d-flex align-items-center">
                    <div class="d-flex justify-content-center align-items-center rounded-circle me-4" style="width: 80px; height: 80px; background-image: linear-gradient(135deg, #f4b70420, #cb278620);"> 
                        <i class="fas fa-user-circle fs-2" style="color: #00617a;"></i> 
                    </div>
                    <div>
                        <h2 class="fs-3 fw-bold mb-1" style="color: #00617a;">Welcome, <?php echo e(Auth::user()->name); ?>!</h2> 
                        <p class="text-muted mb-0">Here's what's happening with your articles and galleries today on **Kamcup**.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <?php $__currentLoopData = [
            ['Articles', $articles, '#cb2786', 'fas fa-newspaper'], /* Primary color */
            ['Published Articles', $articles->filter(fn($a) => strtolower(trim($a->status)) == 'published'), '#00617a', 'fas fa-check-circle'], /* Secondary color */
            ['Galleries', $galleries, '#f4b704', 'fas fa-images'], /* Accent color */
            ['Published Galleries', $galleries->filter(fn($g) => strtolower(trim($g->status)) == 'published'), '#cb2786', 'fas fa-check-circle'] /* Primary color */
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
            <div class="bg-white rounded-3 shadow-sm p-4" style="border: 1px solid <?php echo e($stat[2]); ?>1A;"> 
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-semibold m-0" style="color: #343a40;">Total <?php echo e($stat[0]); ?></h5> 
                    <div class="rounded-circle p-3" style="background-color: <?php echo e($stat[2]); ?>; box-shadow: 0 4px 12px <?php echo e($stat[2]); ?>30;"> 
                        <i class="<?php echo e($stat[3]); ?>" style="color: #fff; font-size: 1.5rem;"></i>
                    </div>
                </div>
                <h3 class="fw-bold text-center" style="color: <?php echo e($stat[2]); ?>;"><?php echo e($stat[1]->count()); ?></h3> 
                <div class="progress mt-2" style="height: 6px; background-color: <?php echo e($stat[2]); ?>20;"> 
                    <div class="progress-bar" role="progressbar" style="width: 100%; background-color: <?php echo e($stat[2]); ?>;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row mb-4">
        <?php $__currentLoopData = [
            ['Articles', $articles, '#cb2786'], /* Primary color */
            ['Galleries', $galleries, '#f4b704'] /* Accent color */
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-3">
            <div class="bg-white rounded-3 shadow-sm p-3" style="border: 1px solid <?php echo e($stat[2]); ?>1A;">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="fw-semibold m-0 fs-6" style="color: #343a40;">Total Views (<?php echo e($stat[0]); ?>)</h5>
                    <div class="rounded-circle p-2" style="background-color: <?php echo e($stat[2]); ?>20;"> 
                        <i class="fas fa-eye" style="color: <?php echo e($stat[2]); ?>; font-size: 1.25rem;"></i> 
                    </div>
                </div>
                <h3 class="fw-bold text-center fs-4" style="color: <?php echo e($stat[2]); ?>;"><?php echo e($stat[1]->sum('views')); ?></h3>
                <div class="progress mt-2" style="height: 4px; background-color: <?php echo e($stat[2]); ?>20;">
                    <div class="progress-bar" role="progressbar" style="width: 100%; background-color: <?php echo e($stat[2]); ?>;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row mb-4">
        <?php $__currentLoopData = [
            ['Today', $today, 'calendar-day', '#cb2786'], /* Primary color */
            ['This Week', $week, 'calendar-week', '#00617a'], /* Secondary color */
            ['This Month', $month, 'calendar-alt', '#f4b704'], /* Accent color */
            ['This Year', $year, 'calendar', '#cb2786'] /* Primary color */
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
            <div class="bg-white rounded-3 shadow-sm p-4" style="border: 1px solid <?php echo e($visit[3]); ?>1A;">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="fw-semibold m-0" style="color: #343a40;"><?php echo e($visit[0]); ?></h6>
                    <i class="fas fa-<?php echo e($visit[2]); ?>" style="color: <?php echo e($visit[3]); ?>;"></i> 
                </div>
                <h4 class="fw-bold text-center" style="color: <?php echo e($visit[3]); ?>;"><?php echo e($visit[1]); ?></h4>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row mb-4">
        <div class="col-md-6 mb-3 d-flex">
            <div class="bg-white rounded-3 shadow-sm p-4 flex-fill" style="border: 1px solid rgba(0, 97, 122, 0.1);">
                <h5 class="fw-semibold mb-3" style="color: #00617a;"> 
                    <i class="fas fa-chart-line me-2"></i> Page Visits
                </h5>
                <ul class="list-unstyled mb-0">
                    <?php $__currentLoopData = [
                        ['Homepage', $homeVisit, 'home', '#cb2786'], /* Primary */
                        ['Articles', $articleVisit, 'newspaper', '#00617a'], /* Secondary */
                        ['Galleries', $galleryVisit, 'images', '#f4b704'], /* Accent */
                        ['Contact', $contactVisit, 'envelope', '#cb2786'] /* Primary */
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mb-2">
                        <i class="fas fa-<?php echo e($page[2]); ?> me-2" style="color: <?php echo e($page[3]); ?>;"></i>
                        <?php echo e($page[0]); ?>: <strong style="color: #343a40;"><?php echo e($page[1]); ?></strong> visits
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <div class="col-md-6 mb-3 d-flex">
            <div class="bg-white rounded-3 shadow-sm p-4 flex-fill" style="border: 1px solid rgba(0, 97, 122, 0.1);">
                <h5 class="fw-semibold mb-3" style="color: #00617a;">
                    <i class="fas fa-users me-2"></i> Total Visits
                </h5>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="fw-bold fs-4" style="color: #cb2786;"><?php echo e($homeVisit + $articleVisit + $galleryVisit + $contactVisit); ?></span> 
                </div>

                <hr style="border-color: rgba(0, 97, 122, 0.2);">

                <div>
                    <h6 class="fw-semibold mb-2" style="color: #6c757d;">Homepage Stats</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-1">
                            <i class="fas fa-calendar-day me-2" style="color: #cb2786;"></i>
                            Today: <strong style="color: #343a40;"><?php echo e($homeVisitToday); ?></strong>
                        </li>
                        <li class="mb-1">
                            <i class="fas fa-calendar-week me-2" style="color: #00617a;"></i>
                            This Week: <strong style="color: #343a40;"><?php echo e($homeVisitWeek); ?></strong>
                        </li>
                        <li class="mb-1">
                            <i class="fas fa-calendar-alt me-2" style="color: #f4b704;"></i>
                            This Month: <strong style="color: #343a40;"><?php echo e($homeVisitMonth); ?></strong>
                        </li>
                        <li>
                            <i class="fas fa-calendar me-2" style="color: #cb2786;"></i>
                            This Year: <strong style="color: #343a40;"><?php echo e($homeVisitYear); ?></strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="bg-white rounded-3 shadow-sm p-4" style="border: 1px solid rgba(0, 97, 122, 0.1);">
                <h5 class="fw-semibold mb-3" style="color: #00617a;">Page Visit Statistics Chart</h5>
                <canvas id="visitChart" height="100"></canvas>
            </div>
        </div>
    </div>

    <div class="card border-0 rounded-3 shadow-sm mb-4" style="border: 1px solid rgba(0, 97, 122, 0.1);">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-semibold m-0" style="color: #00617a;">Recent Articles</h4>
                <a href="<?php echo e(route('admin.articles.index')); ?>" class="btn btn-sm px-3" style="background-color: #cb27861A; color: #cb2786; border-radius: 8px; font-weight: 600;">View All</a>
            </div>
            <?php if($articles->count()): ?>
                <div class="row">
                    <?php $__currentLoopData = $articles->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100 border-0 shadow-sm" style="border: 1px solid #f0f0f0;"> 
                                <?php if($article->thumbnail): ?>
                                    <img src="<?php echo e(asset('storage/' . $article->thumbnail)); ?>" class="card-img-top" alt="<?php echo e($article->title); ?>" style="height: 180px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light d-flex justify-content-center align-items-center" style="height: 180px;">
                                        <i class="fas fa-image text-muted fa-2x"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo e(strtolower(trim($article->status)) == 'published' ? '#00617a1A' : '#f5f5f5'); ?>; color: <?php echo e(strtolower(trim($article->status)) == 'published' ? '#00617a' : '#6c757d'); ?>;">
                                            <?php echo e($article->status); ?>

                                        </span>
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: #f4b7041A; color: #f4b704;">
                                            <i class="fas fa-eye me-1"></i> <?php echo e($article->views); ?>

                                        </span>
                                    </div>
                                    <h5 class="card-title fw-semibold" style="color: #343a40;"><?php echo e(Str::limit($article->title, 50)); ?></h5>
                                    <p class="card-text text-muted mb-3" style="height: 60px; overflow: hidden; line-height: 1.5;"><?php echo e(Str::limit($article->description, 100)); ?></p>
                                    <div class="d-grid">
                                        <a href="<?php echo e(route('admin.articles.show', $article->id)); ?>" class="btn btn-sm" style="background-color: #cb2786; color: #fff; border-radius: 8px; font-weight: 600;"> 
                                            View Details <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="card-footer text-muted text-center" style="font-size: 0.85rem; background-color: #f8f9fa;">
                                    Published on <?php echo e(\Carbon\Carbon::parse($article->created_at)->format('F d, Y')); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-muted">No recent articles found.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card border-0 rounded-3 shadow-sm mb-4" style="border: 1px solid rgba(0, 97, 122, 0.1);">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-semibold m-0" style="color: #00617a;">Recent Galleries</h4>
                <a href="<?php echo e(route('admin.galleries.index')); ?>" class="btn btn-sm px-3" style="background-color: #f4b7041A; color: #f4b704; border-radius: 8px; font-weight: 600;">View All</a>
            </div>
            <?php if($galleries->count()): ?>
                <div class="row">
                    <?php $__currentLoopData = $galleries->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100 border-0 shadow-sm" style="border: 1px solid #f0f0f0;">
                                <?php if($gallery->thumbnail): ?>
                                    <img src="<?php echo e(asset('storage/' . $gallery->thumbnail)); ?>" class="card-img-top" alt="<?php echo e($gallery->title); ?>" style="height: 180px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light d-flex justify-content-center align-items-center" style="height: 180px;">
                                        <i class="fas fa-image text-muted fa-2x"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="badge rounded-pill px-3 py-2"
                                              style="background-color: <?php echo e(strtolower(trim($gallery->status)) == 'published' ? '#00617a1A' : '#f5f5f5'); ?>; color: <?php echo e(strtolower(trim($gallery->status)) == 'published' ? '#00617a' : '#6c757d'); ?>;">
                                            <?php echo e($gallery->status); ?>

                                        </span>
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: #f4b7041A; color: #f4b704;">
                                            <i class="fas fa-eye me-1"></i> <?php echo e($gallery->views); ?>

                                        </span>
                                    </div>
                                    <h5 class="card-title fw-semibold" style="color: #343a40;"><?php echo e(Str::limit($gallery->title, 50)); ?></h5>
                                    <p class="card-text text-muted mb-3" style="height: 60px; overflow: hidden; line-height: 1.5;"><?php echo e(Str::limit($gallery->description, 100)); ?></p>
                                    <div class="d-grid">
                                        <a href="<?php echo e(route('admin.galleries.show', $gallery->id)); ?>" class="btn btn-sm" style="background-color: #f4b704; color: #fff; border-radius: 8px; font-weight: 600;"> 
                                            View Details <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="card-footer text-muted text-center" style="font-size: 0.85rem; background-color: #f8f9fa;">
                                    Published on <?php echo e(\Carbon\Carbon::parse($gallery->created_at)->format('F d, Y')); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-muted">No recent galleries found.</p>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('visitChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Homepage', 'Articles', 'Galleries', 'Contact'], // Added 'Contact'
            datasets: [{
                label: 'Page Visits',
                data: [<?php echo e($homeVisit); ?>, <?php echo e($articleVisit); ?>, <?php echo e($galleryVisit); ?>, <?php echo e($contactVisit); ?>], // Added $contactVisit
                backgroundColor: ['#cb2786', '#00617a', '#f4b704', '#7F8C8D'], // Updated colors for consistency, added color for Contact
                borderColor: ['#cb2786', '#00617a', '#f4b704', '#7F8C8D'],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Magang\kersa\kersa\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>